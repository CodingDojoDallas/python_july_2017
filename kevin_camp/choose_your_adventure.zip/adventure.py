from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')
@app.route('/begin')
def begin():
	return render_template('begin.html')
@app.route('/spaceship')
def spaceship():
	return render_template('spaceship.html')
@app.route('/cabin')
def cabin():
	return render_template('cabin.html')
@app.route('/aliens')
def aleins():
	return render_template('aliens.html')
@app.route('/winner')
def winner():
	return render_template('winner.html')
app.run(debug=True)