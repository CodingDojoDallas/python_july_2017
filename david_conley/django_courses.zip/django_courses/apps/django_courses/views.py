from django.shortcuts import render, HttpResponse, redirect
from .models import Course
# Create your views here.
def index(request):
    context={
        'courses': Course.objects.all()
    }

    return render(request, 'djangocourses/index.html', context)

def course(request):
    Course.objects.create(name=request.POST['name'], description=request.POST['description'])
    return redirect('/')

def confirm(request, id):
    course = Course.objects.get(id=id)
    context={
        'courses' : course
    }
    return render(request, "djangocourses/destroy.html", context)

def remove(request, id):
    Course.objects.filter(id=id).delete()
    return redirect('/')
