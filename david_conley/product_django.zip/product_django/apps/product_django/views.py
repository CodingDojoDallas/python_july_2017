from django.shortcuts import render, HttpResponse, redirect
from .models import Product
# Create your views here.
def index(request):
    Product.objects.create(name='David Conley', description='does not know what this is for', weight='100', price='150', cost='300', category='white')
    product = Product.object.all()
    print product
    return render(request, 'productdjango/index.html')
