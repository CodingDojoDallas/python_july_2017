from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/about_me')
@app.route('/web_page')


def index():
	return render_template("index.html")

def web_page():
	return render_template("web_page.html")

def about_me():
	return render_template("about_me.html")

app.run(debug=True) 
