from django.shortcuts import render, HttpResponse, redirect

def index(request):

    return render(request, 'surveydojo/index.html')
# Create your views here.

def results(request):
    if 'count' not in request.session:
        request.session['count'] = 0
    request.session['count'] += 1

    return render(request, 'surveydojo/results.html')

def process(request):

    request.session['name'] = request.POST['name']
    request.session['location'] = request.POST['location']
    request.session['language'] = request.POST['language']
    request.session['comment'] = request.POST['comment']


    return redirect('/results')

def goback(request):

    return redirect('/')
