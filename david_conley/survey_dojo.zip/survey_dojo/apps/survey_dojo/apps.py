from __future__ import unicode_literals

from django.apps import AppConfig


class SurveyDojoConfig(AppConfig):
    name = 'survey_dojo'
