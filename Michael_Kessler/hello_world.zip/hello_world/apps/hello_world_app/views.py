from django.shortcuts import render
#CONTROLLER!!!
def index(request):
	
	print ('hello world')
	return render(request, "hello_world_app/index.html")

# Create your views here.
