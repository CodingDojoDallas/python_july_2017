-- delete from users where user.id > 3
-- select * from users
SELECT users.id, users.email, users.password from users