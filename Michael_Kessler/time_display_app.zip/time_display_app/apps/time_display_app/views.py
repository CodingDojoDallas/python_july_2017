from django.shortcuts import render
from datetime import datetime

def index(request):

	date = datetime.now()

	context = {

		'date': date,

	}
	return render(request, "time_display_app/index.html", context)

# Create your views here.
