from django.shortcuts import render, redirect
from .models import Product

def index(request):
	Product.objects.create(name='Michael Kessler', description='A really cool guy', weight=100, price=100, cost=100, category='awesomeness')

	product = Product.objects.all()

	print product

	return render(request, 'products_app/index.html')
