from __future__ import unicode_literals

from django.apps import AppConfig


class BooksFullAppConfig(AppConfig):
    name = 'books_full_app'
