from django.shortcuts import render, redirect
from .models import Course
def index(request):

	context = {
	'courses': Course.objects.all()
	}

	return render(request, 'courses_app/index.html', context)

def addcourse(request):

	Course.objects.create(coursename=request.POST['coursename'], description=request.POST['description'])

	return redirect('/')

def confirm(request,id):
	course = Course.objects.get(id=id)

	context = {
	'courses': course
	}


	return render(request, 'courses_app/delete.html', context)

def delete(request, id):

	Course.objects.filter(id=id).delete()

	return redirect('/')