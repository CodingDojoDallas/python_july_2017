from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages

def index(request):

	return render(request, 'user_valid_app/index.html')

def adduser(request):
	if request.method == 'POST':

		errors = User.objects.validate(request.POST)

		if not errors:
			newuser = User.objects.create(username=request.POST['username'])

		else: 
			for error in errors:
				messages.error(request, error)
			return redirect('/')
	context = {
	'users' : User.objects.all(),
	'newuser': newuser
	}

	return render(request, 'user_valid_app/success.html', context)