from __future__ import unicode_literals

from django.db import models



class UserManager(models.Manager):
	def validate(self, form_data):
		errors = []

		if len(form_data['username']) < 9:
			errors.append('INVALID USER NAME')
		if len(form_data['username']) > 26:
			errors.append('INVALID USER NAME')
		
		return errors


class User(models.Model):
	username = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now_add = True)

	objects = UserManager()