from django.shortcuts import render, HttpResponse

def index(request):
	# from apps.books_app.models import Book
	# book = Book.objects.create(title="book1", author='author1', published_date='2001-01-01', category='horror')

	return render(request, "books_app/index.html")