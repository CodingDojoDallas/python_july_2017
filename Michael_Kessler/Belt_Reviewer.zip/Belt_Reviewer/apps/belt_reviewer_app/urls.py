from django.conf.urls import url
from . import views          
urlpatterns = [
url(r'^$', views.index),
url(r'^register$', views.register),
url(r'^login$', views.login),
url(r'^books$', views.books),
url(r'^addBook$', views.addBook),
url(r'^submitBook$', views.submitBook),
url(r'^bookReview/(?P<id>\d+)$', views.bookReview),
url(r'^users/(?P<id>\d+)$', views.users),
url(r'^delete/(?P<id>\d+)$', views.delete),
url(r'^logout$', views.logout),
]