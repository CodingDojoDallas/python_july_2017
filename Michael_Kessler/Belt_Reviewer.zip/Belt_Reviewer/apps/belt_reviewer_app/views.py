from django.shortcuts import render, redirect
from .models import User, Book
from django.db.models import Count
from django.contrib import messages
import bcrypt

def index(request):


	return render(request, 'belt_reviewer_app/index.html')

def currentUser(request):		
	user = User.objects.get(id=request.session['user_id'])

	return user

def register(request):
	if request.method == 'POST':
		
		errors = User.objects.validateRegistration(request.POST)

		if not errors:
			user = User.objects.createUser(request.POST)

			request.session['user_id'] = user.id

			return redirect('/books')

		for error in errors:
			messages.error(request, error)
		print errors

	return redirect('/')

def login(request):
	if request.method == 'POST':
		errors = User.objects.validateLogin(request.POST)

		if not errors:
			user = User.objects.filter(email = request.POST['email']).first()

			if user:
				password = str(request.POST['password'])
				user_password = str(user.password)

				hashed_pw = bcrypt.hashpw(password, user_password)

				if hashed_pw == user.password:
					request.session['user_id'] = user.id
					# request.session['first_name'] = first_name
					
					return redirect('/books')

			errors.append('Invalid account information.')
		
		for error in errors:
			messages.error(request, error)

		return redirect('/')

		print request.session['user_id']

		print errors

def users(request, id):
	book = Book.objects.get(id=id)

	context = {
	'book': book
	}

	return render(request, 'belt_reviewer_app/users.html', context)

def books(request):
	if 'user_id' in request.session:
		
		context = {
		'books': Book.objects.all(),
		}

	return render(request, 'belt_reviewer_app/books.html', context)

def addBook(request):
	if 'user_id' in request.session:
		user = currentUser(request)


		context = {
		'user': user
		}

	return render(request, 'belt_reviewer_app/addBook.html', context)

def submitBook(request):
	if request.method == 'POST':

		user = currentUser(request)
		
		book = Book.objects.create(title=request.POST['title'], author=request.POST['author'], review=request.POST['review'], rating=request.POST['rating'], user=user)

		print "!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		route = "/bookReview/" + str(book.id)
		return redirect(route)

def bookReview(request, id):
	
	user = currentUser(request)

	context = {
	'book': Book.objects.get(id=id),
	'user': user
	}
	print context	
	return render(request, 'belt_reviewer_app/bookReview.html', context)

def delete(request, id):
	book = Book.objects.get(id=id)
	book.delete()

	return redirect('/books')

def logout(request):
	if 'user_id' in request.session:
		request.session.pop('user_id')

	return redirect('/')