from django.shortcuts import render

def index(response):

	print "Hello world!!!!!!!!!!!!!!"

	return render(response, 'the_wallsql_app/index.html')
