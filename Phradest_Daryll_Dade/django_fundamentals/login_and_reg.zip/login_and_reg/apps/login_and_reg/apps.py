from __future__ import unicode_literals

from django.apps import AppConfig


class LoginAndRegConfig(AppConfig):
    name = 'login_and_reg'
